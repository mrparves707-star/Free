@echo off
REM ============================================
REM   docker-android - One-Click Launcher
REM   Double-click this file to start the emulator
REM ============================================
title docker-android One-Click
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Run-Android.ps1"
