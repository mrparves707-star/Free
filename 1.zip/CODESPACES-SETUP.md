# Running docker-android on GitHub Codespaces

**Short answer: it will not boot there.** Codespaces machines do not expose `/dev/kvm`,
and the x86_64 Android emulator cannot run without hardware acceleration (you get the exact
same `x86_64 emulation currently requires hardware acceleration!` error as anywhere else
without KVM).

## Verify it yourself in a Codespace
```bash
ls /dev/kvm        # expected: ls: cannot access '/dev/kvm'
grep -c -E 'vmx|svm' /proc/cpuinfo   # expected: 0
```

What also does NOT work on Codespaces:
- Waydroid / Redroid — need `binder` kernel modules (not loadable in Codespaces)
- ARM system images under TCG software emulation — Google removed software emulation for x86 images and ARM guests are far too slow to be usable
- Any `--device /dev/kvm` docker run — there is no device to pass through

So the repo itself (`HQarroum/docker-android`) cannot serve an emulator from a Codespace today.

## What a Codespace IS good for here
- Browsing/forking/hacking on the repo itself
- Preparing and testing an `.apk` with tooling (`aapt`, Gradle) without installing anything locally

For **actually running** the emulator you need one of:
| Option | KVM | Cost | Notes |
|---|---|---|---|
| Your Windows 10 PC (see `WINDOWS10-SETUP.md`) | via WHPX / VMware / Hyper-V | Free | Best option for you |
| GCP/AWS/Azure VM with nested virtualization | Yes | Small hourly fee | `--enable-nested-virtualization` on GCP |
| GitHub Actions **larger** Linux runners | Yes (hardware-accelerated Android) | Paid | See below — good for CI, not for "keeping an emulator open" |
| Appetize.io / BrowserStack App Automate | n/a (runs APKs in a cloud browser) | Free tier | Good for quick APK checks |

## One single command to paste in the Codespace terminal
Everything (check → pull → run → watch logs) in one shot:
```bash
if [ -e /dev/kvm ]; then chmod 666 /dev/kvm 2>/dev/null; docker run -d --name docker-android --device /dev/kvm -e MEMORY=4096 -e CORES=2 -p 5554:5554 -p 5555:5555 halimqarroum/docker-android:api-33 && docker logs -f docker-android; else echo 'NO /dev/kvm on this Codespace - the emulator cannot boot here. See CODESPACES-SETUP.md for alternatives.'; fi
```
Expected result on most Codespaces: the `else` branch — `NO /dev/kvm ...`. That is not a script bug; it is missing hardware virtualization and no command can add it.

If it prints `ANDROID_READY`, connect from your PC:
```powershell
gh codespace ports forward 5555:5555
adb connect 127.0.0.1:5555
```

## Zero-command variant (fork + .devcontainer)
Copy `.devcontainer/` into your fork of the repo, then **Code → Codespaces → Create codespace on main**. The `postCreateCommand` runs `.devcontainer/setup.sh` automatically: KVM present → emulator starts by itself; KVM absent → prints the warning and stays usable for development.

## If you still want the Codespace to *try* it (one click)
This bundle includes a `.devcontainer/` folder. Copy it into a **fork** of the repo, then
**Create codespace** — the post-create script checks for KVM and:
- if `/dev/kvm` exists (some orgs run on bare metal): pulls the image and starts the emulator automatically
- if missing: prints a clear message and leaves the codespace fully usable for development

```bash
# test KVM manually any time after the codespace opens:
ls /dev/kvm
```

To reach a running emulator from your PC (only when KVM existed and it started):
```powershell
# install GitHub CLI once:
winget install GitHub.cli
gh auth login
gh codespace ports forward 5555:5555     # forwards the ADB port to your localhost
adb connect 127.0.0.1:5555               # then use scrcpy as usual
```

## GitHub Actions with real hardware acceleration (larger runners)
GitHub announced hardware-accelerated Android virtualization on **Actions Windows and Linux larger hosted runners** (2023-02-23). Standard `ubuntu-latest` runners are NOT sufficient (the emulator falls back to ~20-minute software boots). On larger Linux runners, Android works with the usual udev fix:

```yaml
jobs:
  android:
    runs-on: ubuntu-latest-4-cores   # a LARGER runner — hardware acceleration
    steps:
      - uses: actions/checkout@v4
      - name: Enable KVM
        run: |
          echo 'KERNEL=="kvm", GROUP="kvm", MODE="0666", OPTIONS+="static_node=kvm"' | sudo tee /etc/udev/rules.d/99-kvm4all.rules
          sudo udevadm control --reload-rules
          sudo udevadm trigger --name-match=kvm
      - uses: reactivecircus/android-emulator-runner@v2
        with:
          api-level: 33
          arch: x86_64
          target: google_apis
          emulator-options: -no-window -gpu swiftshader_indirect -noaudio -no-boot-anim
          script: echo "Emulator booted with KVM"
```
Larger runners are billed per minute, so use this for CI/tests — not for an interactive emulator.

## Bottom line for your setup
You have a Windows 10 laptop with VT-x enabled. Use it:
1. `WINDOWS10-SETUP.md` Option 1 (Android Studio + WHPX) — easiest, no VM needed ⭐
2. or Option 2 (VMware + Ubuntu VM with VT-x/EPT exposed) — runs **this repo** itself

A Codespace is a fine place to read or modify the repo — not to run the emulator.
