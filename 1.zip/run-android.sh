#!/bin/bash
# One-command docker-android runner (for a KVM-enabled Linux machine)
set -e

IMAGE="${IMAGE:-halimqarroum/docker-android:api-33}"   # prebuilt image (per the repo README)
MEMORY="${MEMORY:-4096}"                             # MB — adjust to your machine's RAM
CORES="${CORES:-4}"

echo "=== docker-android runner ==="

# 1) Check Docker
if ! command -v docker >/dev/null 2>&1; then
  echo "[ERROR] Docker is not installed. Install it first:"
  echo "  sudo apt-get update && sudo apt-get install -y docker.io"
  exit 1
fi

# 2) Check KVM (required for Android emulation)
if [ ! -e /dev/kvm ]; then
  echo "[ERROR] /dev/kvm not found!"
  echo "  - On a VM: enable nested virtualization (Intel VT-x/AMD-V)"
  echo "  - On bare metal: enable VT-x/AMD-V in the BIOS"
  echo "  - Linux: sudo modprobe kvm_intel  (or kvm_amd)"
  echo "The x86_64 emulator will not boot without KVM — hardware acceleration is mandatory."
  exit 1
fi
echo "[OK] KVM available: /dev/kvm"

# 3) Pull the image if missing
if ! docker image inspect "$IMAGE" >/dev/null 2>&1; then
  echo "[..] Image not found, pulling: $IMAGE"
  docker pull "$IMAGE"
fi

# 4) Run the container
echo "[..] Starting the emulator (ADB: 5555, console: 5554) ..."
exec docker run -it --rm \
  --device /dev/kvm \
  -e MEMORY="$MEMORY" \
  -e CORES="$CORES" \
  -p 5554:5554 -p 5555:5555 \
  -v ~/android_avd:/data \
  "$IMAGE"
