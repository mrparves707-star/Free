<#
.SYNOPSIS
  docker-android one-click launcher for Windows 11.
  Starts WSL2 + nested virtualization + Docker + the Android emulator.

.DESCRIPTION
  Automatically performs these steps:
    1) Ensures the script runs with Administrator rights
    2) Sets nestedVirtualization=true in .wslconfig (with .bak backup)
    3) Installs Ubuntu (WSL2) if missing (first run may require a reboot)
    4) Installs/starts Docker (docker.io) inside WSL2
    5) Fixes /dev/kvm permissions
    6) Pulls the halimqarroum/docker-android:api-33 image if missing
    7) Starts the emulator container
    8) When ANDROID_READY appears, runs adb connect and launches scrcpy if available

.EXAMPLE
  .\Run-Android.ps1
  .\Run-Android.ps1 -Memory 6144 -Cores 6

.NOTES
  Requirements: Windows 11, VT-x/AMD-V enabled in BIOS, RAM >= 8 GB.
  On the first run a reboot may be required after installing Ubuntu -
  just double-click RUN-ANDROID.bat again afterwards.
#>
[CmdletBinding()]
param(
    [int]$Memory   = 4096,   # Emulator RAM (MB)
    [int]$Cores    = 4,      # Emulator CPU cores
    [string]$Image = 'halimqarroum/docker-android:api-33',
    [string]$ContainerName = 'docker-android'
)

#----------------------------------------------------------
# 0) Admin elevation
#----------------------------------------------------------
$currentUser = [Security.Principal.WindowsIdentity]::GetCurrent()
$isAdmin = ([Security.Principal.WindowsPrincipal]$currentUser).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $isAdmin) {
    Write-Host '[*] Restarting as Administrator...' -ForegroundColor Cyan
    $argList = @('-NoProfile','-ExecutionPolicy','Bypass','-File', "`"$PSCommandPath`"", '-Memory', $Memory, '-Cores', $Cores)
    Start-Process powershell.exe -Verb RunAs -ArgumentList $argList
    exit
}

$ErrorActionPreference = 'Stop'
function Info($m){ Write-Host "[*]  $m" -ForegroundColor Cyan }
function Ok  ($m){ Write-Host "[OK] $m" -ForegroundColor Green }
function Warn($m){ Write-Host "[!]  $m" -ForegroundColor Yellow }
function Die ($m){ Write-Host "[X]  $m" -ForegroundColor Red; Write-Host ''; Read-Host 'Press Enter to exit'; exit 1 }

Write-Host '=========================================' -ForegroundColor Magenta
Write-Host '   docker-android  -  One-Click Setup    ' -ForegroundColor Magenta
Write-Host '=========================================' -ForegroundColor Magenta

#----------------------------------------------------------
# 1) Windows build check (nestedVirtualization needs Win11)
#----------------------------------------------------------
$build = [int](Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion').CurrentBuild
if ($build -lt 22000) {
    Warn "Windows build $build detected - nestedVirtualization only works on Windows 11 (22000+)."
    Warn 'Continuing anyway; if it fails, use a VMware Workstation Ubuntu VM (see WINDOWS-SETUP.md, Option B).'
} else {
    Ok "Windows build $build"
}

#----------------------------------------------------------
# 2) .wslconfig - ensure nestedVirtualization=true
#----------------------------------------------------------
$wslconfig = Join-Path $env:USERPROFILE '.wslconfig'
$existing  = if (Test-Path $wslconfig) { Get-Content $wslconfig } else { @() }
$raw       = ($existing -join "`n")

if ($raw -match 'nestedVirtualization\s*=\s*true') {
    Ok '.wslconfig already has nestedVirtualization=true'
} else {
    if (Test-Path $wslconfig) {
        $backup = "$wslconfig.bak-$(Get-Date -Format yyyyMMdd-HHmmss)"
        Copy-Item $wslconfig $backup
        Info ".wslconfig backup saved: $backup"
    }
    if ($raw -match '(?im)^\s*\[wsl2\]\s*$') {
        # [wsl2] section exists - insert the flag right below it
        $new = New-Object System.Collections.Generic.List[string]
        $inserted = $false
        foreach ($line in $existing) {
            $new.Add($line)
            if ($line -match '(?im)^\s*\[wsl2\]\s*$' -and -not $inserted) {
                $new.Add('nestedVirtualization=true')
                $inserted = $true
            }
        }
        [IO.File]::WriteAllLines($wslconfig, $new)
    } else {
        Add-Content -Path $wslconfig -Value "`n[wsl2]`nnestedVirtualization=true`nmemory=8GB`nprocessors=4" -Encoding ASCII
    }
    Ok 'Added nestedVirtualization=true to .wslconfig'
}

#----------------------------------------------------------
# 3) Install WSL2 + Ubuntu (if missing)
#----------------------------------------------------------
$distros = (wsl.exe -l -q) 2>$null | ForEach-Object { $_ -replace "`0",'' } | Where-Object { $_.Trim() }
if (-not ($distros -match 'Ubuntu')) {
    Info 'Installing Ubuntu (WSL2)...'
    wsl.exe --install -d Ubuntu
    Die 'Ubuntu installed. Reboot, then double-click RUN-ANDROID.bat again.'
}
Ok 'WSL2 + Ubuntu present'

Info 'Restarting WSL2 to apply .wslconfig...'
wsl.exe --shutdown
Start-Sleep -Seconds 3

#----------------------------------------------------------
# 4) Check /dev/kvm
#----------------------------------------------------------
$kvm = ((wsl.exe -u root -- bash -lc 'ls /dev/kvm >/dev/null 2>&1 && echo YES || echo NO') -replace "`0",'').Trim()
if ($kvm -ne 'YES') {
    Die '/dev/kvm not found. Check: BIOS VT-x/SVM = Enabled, .wslconfig has nestedVirtualization=true, and run `wsl --update`.'
}
Ok '/dev/kvm found'
wsl.exe -u root -- bash -lc 'chmod 666 /dev/kvm'
Ok '/dev/kvm permissions fixed'

#----------------------------------------------------------
# 5) Install/start Docker inside WSL2
#----------------------------------------------------------
$hasDocker = ((wsl.exe -u root -- bash -lc 'command -v docker >/dev/null 2>&1 && echo YES || echo NO') -replace "`0",'').Trim()
if ($hasDocker -ne 'YES') {
    Info 'Installing Docker (docker.io) inside WSL2 - first time only, ~2 minutes...'
    wsl.exe -u root -- bash -lc 'apt-get update -qq && DEBIAN_FRONTEND=noninteractive apt-get install -y -qq docker.io'
    if ($LASTEXITCODE -ne 0) { Die 'Docker installation failed. Check your internet connection.' }
    Ok 'Docker installed'
} else {
    Ok 'Docker already installed'
}
Info 'Starting Docker service...'
wsl.exe -u root -- bash -lc '(service docker start >/dev/null 2>&1) || (systemctl start docker >/dev/null 2>&1) || true'
$dockerOk = ((wsl.exe -u root -- bash -lc 'docker info >/dev/null 2>&1 && echo YES || echo NO') -replace "`0",'').Trim()
if ($dockerOk -ne 'YES') { Die 'Docker daemon did not start. Try `sudo service docker start` inside WSL2.' }
Ok 'Docker daemon is running'

#----------------------------------------------------------
# 6) Pull the image (if missing)
#----------------------------------------------------------
$img = ((wsl.exe -u root -- bash -lc "docker image inspect $Image >/dev/null 2>&1 && echo YES || echo NO") -replace "`0",'').Trim()
if ($img -ne 'YES') {
    Info "Pulling image: $Image (~11 GB - first download can take a while)..."
    wsl.exe -u root -- bash -lc "docker pull $Image"
    if ($LASTEXITCODE -ne 0) { Die 'Image pull failed. Check your internet connection.' }
    Ok 'Image pulled'
} else {
    Ok 'Image already present'
}

#----------------------------------------------------------
# 7) Remove any stale container with the same name, then start
#----------------------------------------------------------
wsl.exe -u root -- bash -lc "docker rm -f $ContainerName >/dev/null 2>&1 || true"
Info 'Starting the emulator...'
wsl.exe -u root -- bash -lc "mkdir -p /root/android_avd && docker run -d --name $ContainerName --device /dev/kvm -e MEMORY=$Memory -e CORES=$Cores -p 5555:5555 -p 5554:5554 -v /root/android_avd:/data $Image >/dev/null"
if ($LASTEXITCODE -ne 0) { Die "Container failed to start. See logs: wsl -u root -- docker logs $ContainerName" }
Ok "Container '$ContainerName' started"

#----------------------------------------------------------
# 8) Wait for ANDROID_READY (max 5 minutes)
#----------------------------------------------------------
Info 'Emulator booting - usually 1 to 5 minutes...'
$ready = $false
for ($i = 0; $i -lt 60; $i++) {
    Start-Sleep -Seconds 5
    $state = (wsl.exe -u root -- bash -lc "docker logs $ContainerName 2>&1 | grep -E 'ANDROID_READY|ANDROID_STOPPED' | tail -1")
    $state = ($state -replace "`0",'').Trim()
    if ($state -match 'ANDROID_READY')   { $ready = $true; break }
    if ($state -match 'ANDROID_STOPPED') { break }
    Write-Host '.' -NoNewline
}
Write-Host ''
if (-not $ready) {
    Warn 'ANDROID_READY did not arrive in time. Last logs:'
    wsl.exe -u root -- bash -lc "docker logs $ContainerName 2>&1 | tail -25"
    Die 'Emulator did not boot - check the error in the log above.'
}
Ok 'ANDROID_READY - emulator is up!'

#----------------------------------------------------------
# 9) adb connect (+ scrcpy screen if available)
#----------------------------------------------------------
$adb = Get-Command adb -ErrorAction SilentlyContinue
if ($adb) {
    Info 'Connecting ADB...'
    & adb connect 127.0.0.1:5555 | Out-Null
    Ok 'adb connected to 127.0.0.1:5555'
    $scrcpy = Get-Command scrcpy -ErrorAction SilentlyContinue
    if ($scrcpy) {
        Info 'Opening the screen with scrcpy...'
        Start-Process scrcpy -ArgumentList '-s','127.0.0.1:5555'
    } else {
        Warn 'scrcpy not found - to view the screen: winget install Genymobile.scrcpy'
    }
} else {
    Warn 'adb not found - install platform-tools: winget install Google.PlatformTools'
}

Write-Host ''
Write-Host '=========================================' -ForegroundColor Green
Write-Host '  Done! The emulator is running.         ' -ForegroundColor Green
Write-Host '  adb connect 127.0.0.1:5555  (attach)   ' -ForegroundColor Green
Write-Host '  scrcpy -s 127.0.0.1:5555    (screen)   ' -ForegroundColor Green
Write-Host "  Stop: wsl -u root -- docker rm -f $ContainerName" -ForegroundColor Green
Write-Host '=========================================' -ForegroundColor Green
Write-Host ''
Read-Host 'Press Enter to close this window (the emulator keeps running)'
