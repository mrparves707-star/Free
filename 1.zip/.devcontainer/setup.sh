#!/bin/bash
# Post-create script for the docker-android devcontainer (GitHub Codespaces).
# Checks for KVM and, if present, pulls and starts the emulator.
set -e

IMAGE="halimqarroum/docker-android:api-33"
MEMORY="${MEMORY:-4096}"
CORES="${CORES:-2}"

echo "=== docker-android devcontainer setup ==="

if [ ! -e /dev/kvm ]; then
  echo ""
  echo "[!] /dev/kvm is NOT available on this Codespaces machine."
  echo "    The Android emulator cannot boot without hardware virtualization."
  echo "    This codespace is still fully usable for developing/reading the repo."
  echo "    To actually RUN the emulator, use your own machine:"
  echo "    - Windows 10/11: see WINDOWS10-SETUP.md / WINDOWS-SETUP.md"
  echo "    - or a cloud VM with nested virtualization"
  echo ""
  exit 0
fi

echo "[OK] /dev/kvm found — starting the emulator..."
sudo chmod 666 /dev/kvm || true
docker pull "$IMAGE"
docker rm -f docker-android >/dev/null 2>&1 || true
docker run -d --name docker-android --device /dev/kvm \
  -e MEMORY="$MEMORY" -e CORES="$CORES" \
  -p 5554:5554 -p 5555:5555 \
  -v /workspaces/docker-android-avd:/data \
  "$IMAGE"
echo "[OK] Container started. Follow logs with: docker logs -f docker-android"
echo "     Forward port 5555 to your machine and run: adb connect 127.0.0.1:5555"
