# Run docker-android / an Android emulator on Windows 10

Your PC: Intel i3-4160 (2C/4T, VT-x **Enabled** ✅), 8 GB RAM, SSD.
Windows **10** does NOT officially support WSL2 nested virtualization, so the
one-click `.wslconfig nestedVirtualization=true` path does not apply here.

Three working paths, easiest first:

---

## Option 1 — Android Studio AVD (recommended on this hardware)
No Docker, no VM, uses WHPX hardware acceleration on Windows 10.
It does **not** run this repo — it gives you the same end result (an Android emulator) directly.

1. Check your build: Win+R → `winver` → you should be on Windows 10 1903+.
2. Enable the Windows Hypervisor Platform — PowerShell **(Admin)**:
   ```powershell
   dism.exe /online /enable-feature /featurename:HypervisorPlatform /all /norestart
   ```
   Then **reboot**.
   (GUI alternative: Control Panel → Programs → "Turn Windows features on or off" → tick **Windows Hypervisor Platform** → OK.)
3. Download & install Android Studio: <https://developer.android.com/studio> (Standard setup).
4. Open Android Studio → **Device Manager** → **Create Virtual Device**
   - Pick a **small** device for your i3 (e.g. Pixel 3a / any 720x1280 profile) — smaller than Pixel 1080x1920, much faster boot
   - System image: **API 30 or API 33**, **x86_64**, target Google APIs (NOT "google_apis_playstore" unless you need Play — it is heavier)
   - If prompted, install the system image + accept licenses
5. Press the ▶ Run button next to the AVD. First boot on an i3-4160 can take several minutes.
6. Use adb (bundled with SDK) or `scrcpy` to mirror the screen.

**Why this is best here:** zero VM overhead, direct WHPX acceleration, works on Windows 10 Home, and it tolerates low RAM better than a VM.

---

## Option 2 — The actual repo inside a VMware Workstation VM (works on Home edition)
VMware Player can expose VT-x/EPT to a guest VM → KVM works inside Ubuntu → the repo runs as designed.

1. Download **VMware Workstation Player** (free for personal use):
   <https://www.vmware.com/products/workstation-player.html>
2. Download **Ubuntu 22.04 LTS desktop** ISO: <https://ubuntu.com/download/desktop> (~5 GB).
3. New VM in Player:
   - RAM: **4 GB** (max you can spare — Windows already uses ~3.7 GB; close Chrome/apps first)
   - Processors: 2 cores
   - Disk: 25 GB, split/store as single file, preallocate off
   - Network: **Bridged** (so Windows can reach the emulator's adb directly; NAT would hide it)
   - Before finishing the wizard: **Customize Hardware → Processors → check "Virtualize Intel VT-x/EPT or AMD-V/RVI"** ← the critical setting
4. Install Ubuntu normally (any user/password).
5. Inside Ubuntu, add a swap file (important with 8 GB RAM):
   ```bash
   sudo fallocate -l 4G /swapfile
   sudo chmod 600 /swapfile && sudo mkswap /swapfile && sudo swapon /swapfile
   echo '/swapfile none swap sw 0 0' | sudo tee -a /etc/fstab
   ```
6. Install Docker + git, clone, pull, run:
   ```bash
   sudo apt-get update && sudo apt-get install -y docker.io git
   sudo usermod -aG docker $USER          # log out / log in afterwards (or prefix docker with sudo)
   git clone https://github.com/HQarroum/docker-android.git
   cd docker-android
   docker pull halimqarroum/docker-android:api-33   # ~11 GB — use a fast connection
   docker run -it --rm --device /dev/kvm -e MEMORY=2048 -e CORES=2 \
     -p 5555:5555 -p 5554:5554 halimqarroum/docker-android:api-33
   ```
   Verify KVM inside the VM: `ls /dev/kvm` — if it exists, the emulator will boot.
   If `/dev/kvm` is missing: the "Virtualize VT-x/EPT" checkbox didn't stick, or EPT is not available → fall back to Option 1.
7. From **Windows** (not the VM): install platform-tools (<https://developer.android.com/tools/releases/platform-tools>)
   ```powershell
   hostname -I     # (run this inside Ubuntu to get the VM's IP, e.g. 192.168.x.x)
   adb connect <VM-IP>:5555
   ```
   Then screen with scrcpy: `scrcpy -s <VM-IP>:5555`

---

## Option 3 — Hyper-V (Windows 10 **Pro** / Enterprise / Education only)
Windows 10 Home does NOT include Hyper-V. If you have Pro:

```powershell
# PowerShell (Admin)
Enable-WindowsOptionalFeature -Online -FeatureName Microsoft-Hyper-V -All
Enable-WindowsOptionalFeature -Online -FeatureName VirtualMachinePlatform -All
Restart-Computer
```
Create an Ubuntu VM in Hyper-V Manager, then in PowerShell:
```powershell
Set-VMProcessor -VMName "Ubuntu" -ExposeVirtualizationExtensions $true
```
(VM must be powered off when you run this.) Boot it and follow **Option 2, steps 5–7** (NAT is the default in Hyper-V — either switch the vSwitch to External/Bridged, or add a port-forward rule for 5555).

---

## Reality check for your hardware (i3-4160 + 8 GB)
- Your Task Manager shows **3.7 GB used already** — the emulator + Windows will fight for RAM.
  → Close browsers / heavy apps before starting anything, and use `MEMORY=2048`.
- Boot will be **slow** (minutes). Subsequent boots are faster.
- The Android image is ~11 GB and Ubuntu ISO ~5 GB — make sure at least **~20 GB free** on C:.
- If anything OOMs or the machine crawls, Option 1 with a **small device + API 28/30** is the lightest path.
- `scrcpy` (screen mirror) on Windows: <https://github.com/Genymobile/scrcpy> — `winget install Genymobile.scrcpy`

## Which should you pick?
| Your situation | Pick |
|---|---|
| Windows 10 Home (or not sure) | **Option 1 – Android Studio** |
| Windows 10 Pro/Enterprise, must run *this repo* | Option 3 – Hyper-V |
| Windows 10 Home, must run *this repo* | Option 2 – VMware Player |
| Just want Android on screen, easiest & free | **Option 1 – Android Studio** |
