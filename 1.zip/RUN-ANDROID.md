# docker-android — Run Report

Repo: https://github.com/HQarroum/docker-android
(An Android Emulator running headless inside a Docker container — remotely controllable over the network via ADB / scrcpy.)

## ✅ What was done in this environment
1. Repo cloned → `/home/user/docker-android`
2. Docker (26.1.5) installed and daemon started (with compose support — `docker-compose`)
3. ADB keys present (`docker-android/keys/`)
4. `docker-compose config` — compose file is valid ✔
5. Prebuilt image pulled: `halimqarroum/docker-android:api-33` (~11.3 GB)
6. Attempted to run — **the emulator did not boot**, because this sandbox's CPU has no `vmx`/`svm` flag and `/dev/kvm` does not exist.
   Actual container log:
   ```
   ERROR | x86_64 emulation currently requires hardware acceleration!
   CPU acceleration status: KVM requires a CPU that supports vmx or svm
   { "type": "state-update", "value": "ANDROID_STOPPED" }
   ```
   In addition, this VM has only **1.9 GB RAM** (the emulator needs at least 4 GB).

➡️ **Conclusion: the Android emulator cannot run in this cloud sandbox.** That is a limitation of the environment, not of the repo.

## 🪟 Windows? → Use the one-click launcher or see the Windows guide
See **`WINDOWS-SETUP.md`** and the **`oneclick/`** folder:
- Double-click **`oneclick/RUN-ANDROID.bat`** and everything is automated
  (WSL2 + nested virtualization + Docker + image pull + emulator start).

## 🖥️ Run it on your own machine (Linux + KVM required)

**Requirements:** x86_64 Linux, virtualization enabled (VT-x / AMD-V), RAM ≥ 8 GB, disk ≥ 10 GB, Docker.

```bash
# 1) Check KVM (this must return something)
ls /dev/kvm
grep -E -o '(vmx|svm)' /proc/cpuinfo | head -1

# 2) Install Docker (if missing)
sudo apt-get update && sudo apt-get install -y docker.io

# 3a) Run the prebuilt image (easiest)
docker pull halimqarroum/docker-android:api-33
docker run -it --rm --device /dev/kvm -p 5555:5555 -p 5554:5554 \
  -e MEMORY=4096 -e CORES=4 \
  -v ~/android_avd:/data \
  halimqarroum/docker-android:api-33

# 3b) Or build from source
cd docker-android
docker build -t android-emulator .
docker run -it --rm --device /dev/kvm -p 5555:5555 android-emulator

# 4) Connect (from another terminal)
adb connect 127.0.0.1:5555     # Android Debug Bridge
scrcpy -s 127.0.0.1:5555       # view/control the screen (if scrcpy is installed)
```

Or use the helper script included here:
```bash
./run-android.sh              # override with: MEMORY=8192 CORES=8 ./run-android.sh
```

> ⚠️ The default `docker-compose.yml` sets `MEMORY=16384` and `CORES=16` — lower these to match your machine or it may OOM.
> To run via compose: `docker-compose up android-emulator` (it will fail without `/dev/kvm`).

## 🚫 Where it will NOT run
- **Vercel** — serverless platform; no Docker-in-Docker / KVM / privileged containers. Not possible there.
- Any sandbox/CI container without KVM (like this environment).
- macOS with Docker — no KVM, this x86_64 emulator will not boot.

## ☁️ If you have no KVM anywhere (cloud options)
- **GCP Compute Engine**: create an Intel/AMD VM with nested virtualization enabled (`--enable-nested-virtualization`), then follow the Linux steps above.
- Otherwise: **Appetize.io** / **BrowserStack App Automate** (test APKs in the browser), **Genymotion Cloud**, or **Android Studio**'s emulator on your PC — none of these require a KVM server.

## 📁 Files
- `oneclick/RUN-ANDROID.bat` + `oneclick/Run-Android.ps1` — **one-click launcher** (Windows 11; double-click to start the emulator)
- `WINDOWS-SETUP.md` — Full guide for Windows 11 (WSL2 + nested virtualization)
- `WINDOWS10-SETUP.md` — Full guide for Windows 10 (Android Studio / VMware / Hyper-V)
- `CODESPACES-SETUP.md` — Why it won't run on GitHub Codespaces + what to do instead
- `devcontainer/` — Ready-made `.devcontainer/` for a fork (auto-starts the emulator *if* KVM exists)
- `/home/user/docker-android/` — cloned repo (compose, Dockerfile, scripts, keys)
- `/home/user/run-android.sh` — one-command runner script (with KVM check)
- `/home/user/RUN-ANDROID.md` — this report
