# Run docker-android on Windows

> ⚠️ **Using Windows 10?** The nested-virtualization path below does not apply.
> See **`WINDOWS10-SETUP.md`** instead (Android Studio / VMware / Hyper-V options).
>
> ## 🚀 Easiest path (Windows 11): one-click
> 1. Keep these two files in the same folder: **`oneclick/RUN-ANDROID.bat`** and **`oneclick/Run-Android.ps1`**
> 2. **Double-click `RUN-ANDROID.bat`** (that's your one click)
> 3. The script automatically handles: `.wslconfig` nested virtualization → WSL2 + Ubuntu → Docker install → image pull → emulator start → `adb connect` (+ opens scrcpy if installed)
> 4. **On the first run** it may install Ubuntu and ask you to reboot — just double-click again after the reboot and everything completes.
>
> Requirements: Windows 11 + VT-x/AMD-V enabled in BIOS + RAM ≥ 8 GB.
> If any step fails, follow the manual guide below — it explains exactly what the script does.

---

## Requirements
- **Windows 11** (nested virtualization only works on Windows 11; Windows 10 users → see Option B)
- CPU virtualization enabled in **BIOS/UEFI**: Intel VT-x / AMD-V
- RAM ≥ 8 GB (16 GB recommended), disk ≥ 15 GB free
- Administrator PowerShell

---

## Step 1 — Enable virtualization in BIOS/UEFI
Reboot into BIOS/UEFI and find:
- Intel: `Intel Virtualization Technology (VT-x)` → **Enabled**
- AMD: `SVM Mode` / `AMD-V` → **Enabled**
Save and exit.

## Step 2 — Install WSL2 + Ubuntu
In PowerShell (Admin):
```powershell
wsl --install -d Ubuntu
```
Reboot. The first launch asks you to set a username and password.
(If WSL is already installed: run `wsl --update` to stay current.)

## Step 3 — Enable nested virtualization (the key step)
Open PowerShell and run:
```powershell
notepad $env:USERPROFILE\.wslconfig
```
Put the following into it (create it if missing):
```ini
[wsl2]
nestedVirtualization=true
memory=10GB
processors=4
```
> Adjust `memory`/`processors` to your PC. Use `memory=6GB` if RAM is tight.

Then fully shut WSL down and open Ubuntu again:
```powershell
wsl --shutdown
```
Check that KVM is now available:
```bash
ls -l /dev/kvm
```
If you still get `ls: cannot access '/dev/kvm'`:
1. Confirm you are on Windows 11 (`winver`) — it will not work on Windows 10, use Option B below
2. Run `wsl --version` — if outdated, run `wsl --update`
3. Double-check virtualization is enabled (Task Manager → Performance → CPU → "Virtualization: Enabled")

## Step 4 — Fix /dev/kvm permissions
```bash
sudo usermod -aG kvm $USER      # if a kvm group exists
sudo chmod 666 /dev/kvm         # temporary fix for this session
```
Permanent fix — set it on every WSL boot via `/etc/wsl.conf`:
```bash
sudo nano /etc/wsl.conf
```
```ini
[boot]
command = /bin/bash -c 'chown -v root:kvm /dev/kvm && chmod 660 /dev/kvm'
```
Save → `wsl --shutdown` (PowerShell) → open Ubuntu again.

## Step 5 — Install Docker (inside the WSL2 Ubuntu)
```bash
sudo apt-get update
sudo apt-get install -y docker.io
sudo service docker start
sudo usermod -aG docker $USER
```
Open a new terminal (or run `newgrp docker`), then verify:
```bash
docker run --rm hello-world
```

> 💡 You can also try Docker Desktop (Windows app) with the WSL2 backend, but `/dev/kvm` may not be present inside its utility VM.
> If it isn't, use the WSL2 `docker.io` install shown above — that is the reliable path for this project.

## Step 6 — Start the emulator
```bash
git clone https://github.com/HQarroum/docker-android.git
cd docker-android
docker pull halimqarroum/docker-android:api-33
docker run -it --rm --device /dev/kvm -p 5555:5555 -p 5554:5554 \
  -e MEMORY=4096 -e CORES=4 \
  halimqarroum/docker-android:api-33
```
The first boot can take 2–5 minutes; wait for `ANDROID_READY` in the logs.
You can raise `MEMORY` if you have the RAM (the default compose file sets 16384 — lower it to match your machine).

To build from source instead:
```bash
docker build -t android-emulator .
docker run -it --rm --device /dev/kvm -p 5555:5555 android-emulator
```

## Step 7 — Connect from Windows with ADB and view the screen
Download **platform-tools** for Windows: <https://developer.android.com/tools/releases/platform-tools>
(unzip and add the folder to PATH, or run `adb.exe` directly)

Ports from WSL2 are forwarded to `localhost` automatically, so from Windows:
```powershell
adb connect 127.0.0.1:5555
adb devices
```
To view/control the screen, use **scrcpy**: <https://github.com/Genymobile/scrcpy>
```powershell
scrcpy -s 127.0.0.1:5555
```

---

## Option B — Windows 10, or nested virtualization doesn't work
**VMware Workstation Player** (free for personal use):
1. Create an Ubuntu VM inside it
2. VM Settings → Processors → check **"Virtualize Intel VT-x/EPT or AMD-V/RVI"**
3. Inside the Ubuntu VM follow **Steps 5–7** above (no WSL2 needed)

## Option C — No virtualization possible at all (simplest fallback)
Install **Android Studio** directly on Windows → AVD Manager → create a Pixel AVD with API 33+ → Run.
It uses WHPX (Windows Hypervisor Platform) hardware acceleration; no Docker required.
For browser-based APK testing without any emulator: **Appetize.io**, **BrowserStack App Automate**.

---

## Troubleshooting
| Problem | Fix |
|---|---|
| `x86_64 emulation currently requires hardware acceleration!` | `/dev/kvm` missing or no permission → Steps 3–4 |
| `docker: permission denied` | `sudo usermod -aG docker $USER` → open a new shell |
| `Cannot connect to the Docker daemon` | `sudo service docker start` |
| `adb connect` fails | Check Windows Firewall for port 5555; confirm the container runs (`docker ps` inside WSL) |
| Emulator is very slow | Raise `MEMORY`/CPU, or set `DISABLE_ANIMATION=true` |

## Good to know
- The ~11.3 GB image pulled in this sandbox lives only in this Linux VM — you must `docker pull` it again on your Windows PC.
- The `docker-compose.yml` defaults (`MEMORY=16384`, `CORES=16`) are too big for most machines — scale them down.
